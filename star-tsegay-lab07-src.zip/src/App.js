import "./App.css";
import DashBoard from "./Pages/DashBoard/DashBoard";

function App() {
  return (
    <div className="App">
      <h1>hello there!!</h1>
      <DashBoard />
    </div>
  );
}

export default App;
