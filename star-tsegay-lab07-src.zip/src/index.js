import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';


// const element = <h1>I am Bab! nice to meet you!</h1>

// ReactDOM.render(element, document.getElementById("root"));
ReactDOM.render(<App />, document.getElementById("root"));

//ReactDOM.render(<h1>Hello Everyone</h1>, document.getElementById('root2'));


//reportWebVitals();
